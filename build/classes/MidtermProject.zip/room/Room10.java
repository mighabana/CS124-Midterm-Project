package room;

import main_package.Command;
import main_package.GameState;
import main_package.Room;
import main_package.Drawer;

/**
 *
 * @author Luis Ligunas
 */
public class Room10 extends Room {

    private Drawer runner;

    public Room10(Drawer runner) {
        this.runner = runner;
    }
    
    public String entry() {
        
        GameState.getInstance().setCurrRoom(this);
        GameState.getInstance().setDead(true);
        return "You're done, I guess.";
    }
    
    @Command(command="help", name="help")
    @Override
    public String help() {
        return super.help();
    }
    
    @Command(command=Room.TAKE_ITEM_COMMAND, name=Room.TAKE_ITEM_NAME)
    public String takeItem() {
        String itemString = runner.getLastInput();
        itemString = itemString.substring(itemString.indexOf("take") + 5);
        
        return takeItem(itemString);
    }
    
    @Command(command = Room.USE_ITEM_COMMAND, name = Room.USE_ITEM_NAME)
    public String useItem() {
        String itemName = runner.getLastInput();
        itemName = itemName.substring(itemName.indexOf("use") + 4);
        
        return useItem(itemName);
    }
}
